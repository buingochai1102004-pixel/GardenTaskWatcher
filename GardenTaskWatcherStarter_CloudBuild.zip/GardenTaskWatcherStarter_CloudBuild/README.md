# Garden Task Watcher Starter

Bản này là app Android starter cho bot theo dõi nhiệm vụ game Thế Giới Hoa Viên.

## Mục tiêu v0.1

- Xin quyền chụp màn hình bằng MediaProjection.
- Dùng AccessibilityService để vuốt danh sách nhiệm vụ.
- Cắt 9 slot cố định theo ảnh mẫu 686x1536.
- OCR text trong từng slot bằng ML Kit Text Recognition.
- Phân loại slot: WAITING / DOING / VIP / AVAILABLE / UNKNOWN.
- Cắt icon của slot AVAILABLE.
- Lưu icon mới vào `filesDir/icons`.
- Tạo hash icon để nhận biết icon cũ/mới.
- Ghi tin Zalo vào log trước, chưa gửi thật để tránh spam.

## Cách chạy

1. Mở project bằng Android Studio.
2. Sync Gradle.
3. Cắm điện thoại Android.
4. Build & Run app.
5. Trên điện thoại:
   - Cài game và Zalo.
   - Mở game tới màn hình nhiệm vụ.
   - Bật Trợ năng cho `Garden Task Watcher`.
   - Mở app bot, bấm `Xin quyền chụp màn hình`.
6. Bot sẽ bắt đầu chụp màn hình, cắt slot, OCR, lướt, và ghi log.

## File log trong máy

App ghi các file trong private app storage:

- `garden_watcher.log`: log chính.
- `pending_zalo_messages.log`: tin nhắn dự kiến gửi Zalo.
- `icons_db.json`: danh sách icon đã lưu.
- `icons/ICON_0001.png`: ảnh icon.
- `debug_slots/page_x/slot_y_STATUS.png`: ảnh debug từng slot.

Có thể xem bằng Android Studio:

View > Tool Windows > Device Explorer > data/data/com.phuc.gardentaskwatcher/files

## Lưu ý

- Đây là bản starter để test nhận diện, chưa phải bản chạy 24/24 hoàn chỉnh.
- Nếu tọa độ slot lệch, chỉnh trong `BotConfig.kt`.
- Nếu bot nhận sai trạng thái, xem ảnh trong `debug_slots` rồi chỉnh `StatusClassifier.kt`.
- V1 chưa gửi Zalo thật. Sau khi log đúng, mới nối ZaloNotifier với API hoặc module tự gửi.

## Bước tiếp theo

1. Cài vào máy.
2. Chạy thử 10 phút.
3. Lấy `garden_watcher.log`, `pending_zalo_messages.log`, `icons_db.json`, và vài ảnh trong `debug_slots`.
4. Gửi lại để căn classifier chính xác hơn.
