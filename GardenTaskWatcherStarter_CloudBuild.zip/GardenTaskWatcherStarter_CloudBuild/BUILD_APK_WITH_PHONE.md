# Build APK bằng điện thoại, không cần máy tính

File ZIP này đã có sẵn GitHub Actions workflow tại:

`.github/workflows/build-apk.yml`

Cách dùng trên điện thoại:

1. Tạo tài khoản GitHub nếu chưa có.
2. Vào github.com bằng Chrome.
3. Tạo repository mới, ví dụ: `GardenTaskWatcher`.
4. Upload toàn bộ code trong ZIP này lên repository.
5. Vào tab `Actions`.
6. Chọn workflow `Build APK`.
7. Bấm `Run workflow`.
8. Chờ build xong.
9. Mở run vừa chạy.
10. Tải artifact `GardenTaskWatcher-debug-apk`.
11. Giải nén artifact để lấy `app-debug.apk`.
12. Upload APK đó vào Redfinger và cài.

Lưu ý:
- Đây là APK debug để test nhận diện trước.
- Chưa gửi Zalo thật; bản đầu chỉ ghi log để tránh spam.
- Khi nhận diện đúng, mới nối module gửi Zalo.
