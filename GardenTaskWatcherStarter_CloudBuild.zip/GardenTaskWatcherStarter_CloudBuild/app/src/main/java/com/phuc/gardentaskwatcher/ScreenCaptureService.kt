package com.phuc.gardentaskwatcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.phuc.gardentaskwatcher.START"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "garden_task_watcher"
        private const val NOTIFICATION_ID = 1001
    }

    private var projection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var latestBitmap: Bitmap? = null
    private val workerThread = HandlerThread("GardenWatcherWorker")
    private lateinit var worker: Handler
    private val isRunning = AtomicBoolean(false)
    private val isScanning = AtomicBoolean(false)

    private lateinit var scanner: TaskScanner
    private lateinit var iconRepository: IconRepository
    private lateinit var taskStateRepository: TaskStateRepository
    private lateinit var notifier: ZaloNotifier

    override fun onCreate() {
        super.onCreate()
        workerThread.start()
        worker = Handler(workerThread.looper)
        scanner = TaskScanner(this)
        iconRepository = IconRepository(this)
        taskStateRepository = TaskStateRepository(this)
        notifier = ZaloNotifier(this)
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Đang chờ quyền chụp màn hình"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
            val data = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
            if (resultCode != -1 && data != null) {
                startProjection(resultCode, data)
            }
        }
        return START_STICKY
    }

    private fun startProjection(resultCode: Int, data: Intent) {
        if (isRunning.getAndSet(true)) return

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)

        val metrics = getScreenMetrics()
        imageReader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)

        projection?.createVirtualDisplay(
            "GardenTaskWatcherDisplay",
            metrics.widthPixels,
            metrics.heightPixels,
            metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            worker
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                latestBitmap?.recycle()
                latestBitmap = imageToBitmap(image)
            } catch (e: Exception) {
                LogStore.append(applicationContext, "imageToBitmap error: ${e.message}")
            } finally {
                image.close()
            }
        }, worker)

        LogStore.append(this, "Screen capture started: ${metrics.widthPixels}x${metrics.heightPixels}")
        updateNotification("Đang theo dõi nhiệm vụ")
        scheduleNextScan(2_000L)
    }

    private fun scheduleNextScan(delayMs: Long = BotConfig.SCAN_INTERVAL_MS) {
        if (!isRunning.get()) return
        worker.postDelayed({
            if (isScanning.compareAndSet(false, true)) {
                try {
                    runScanCycle()
                } catch (e: Exception) {
                    LogStore.append(applicationContext, "scanCycle error: ${e.message}")
                } finally {
                    isScanning.set(false)
                    scheduleNextScan()
                }
            }
        }, delayMs)
    }

    private fun runScanCycle() {
        LogStore.append(this, "=== New scan cycle ===")

        var samePageCount = 0
        var previousSignature: String? = null

        for (pageIndex in 0 until BotConfig.MAX_PAGES_PER_CYCLE) {
            val screenshot = latestBitmap?.copy(Bitmap.Config.ARGB_8888, false)
            if (screenshot == null) {
                LogStore.append(this, "No screenshot yet")
                Thread.sleep(1000)
                continue
            }

            val page = scanner.scanPage(screenshot, pageIndex)
            LogStore.append(this, page.summary())

            for (slot in page.slots) {
                if (slot.status == TaskStatus.AVAILABLE && slot.iconBitmap != null) {
                    val icon = iconRepository.findOrCreate(slot.iconBitmap)
                    val taskKey = TaskKeyBuilder.build(icon.iconId, slot)
                    if (taskStateRepository.shouldReport(taskKey)) {
                        val message = MessageFormatter.formatNewTask(icon, pageIndex, slot)
                        notifier.sendOrQueue(message)
                        taskStateRepository.markReported(taskKey)
                    }
                }
            }

            if (page.signature == previousSignature) {
                samePageCount++
            } else {
                samePageCount = 0
                previousSignature = page.signature
            }

            screenshot.recycle()

            if (samePageCount >= BotConfig.SAME_PAGE_STOP_COUNT) {
                LogStore.append(this, "Stop cycle: same page repeated")
                break
            }

            val accessibility = WatcherAccessibilityService.instance
            if (accessibility == null) {
                LogStore.append(this, "Accessibility service is OFF. Cannot swipe.")
                break
            } else {
                accessibility.swipeTaskList()
                Thread.sleep(BotConfig.swipe.delayAfterSwipeMs)
            }
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
        bitmap.recycle()
        return cropped
    }

    @Suppress("DEPRECATION")
    private fun getScreenMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(metrics)
        return metrics
    }

    private fun buildNotification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("Garden Task Watcher")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(CHANNEL_ID, "Garden Task Watcher", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        isRunning.set(false)
        try { imageReader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { workerThread.quitSafely() } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
