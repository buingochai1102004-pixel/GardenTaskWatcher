package com.phuc.gardentaskwatcher

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LogStore {
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    @Synchronized
    fun append(context: Context, line: String) {
        val file = File(context.filesDir, "garden_watcher.log")
        file.appendText("${fmt.format(Date())} $line\n")
    }
}
