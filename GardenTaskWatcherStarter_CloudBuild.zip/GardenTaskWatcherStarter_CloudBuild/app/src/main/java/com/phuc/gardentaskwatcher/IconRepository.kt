package com.phuc.gardentaskwatcher

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class IconRepository(private val context: Context) {
    private val iconsDir = File(context.filesDir, "icons").apply { mkdirs() }
    private val dbFile = File(context.filesDir, "icons_db.json")
    private val matchThreshold = 8

    @Synchronized
    fun findOrCreate(iconBitmap: Bitmap): IconRecord {
        val hash = ImageHash.dHash(iconBitmap)
        val all = loadAll().toMutableList()

        val match = all.minByOrNull { ImageHash.hammingDistanceHex(hash, it.hash) }
        if (match != null && ImageHash.hammingDistanceHex(hash, match.hash) <= matchThreshold) {
            val updated = match.copy(seenCount = match.seenCount + 1)
            val newList = all.map { if (it.iconId == match.iconId) updated else it }
            saveAll(newList)
            return updated
        }

        val newId = "ICON_" + (all.size + 1).toString().padStart(4, '0')
        val path = File(iconsDir, "$newId.png")
        path.outputStream().use { out ->
            iconBitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }

        val record = IconRecord(
            iconId = newId,
            hash = hash,
            imagePath = path.absolutePath,
            confirmedName = null,
            predictedName = null,
            seenCount = 1
        )

        all.add(record)
        saveAll(all)
        LogStore.append(context, "New icon saved: $newId hash=$hash")
        return record
    }

    private fun loadAll(): List<IconRecord> {
        if (!dbFile.exists()) return emptyList()
        val arr = JSONArray(dbFile.readText())
        val list = mutableListOf<IconRecord>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                IconRecord(
                    iconId = o.getString("iconId"),
                    hash = o.getString("hash"),
                    imagePath = o.getString("imagePath"),
                    confirmedName = o.optString("confirmedName").ifBlank { null },
                    predictedName = o.optString("predictedName").ifBlank { null },
                    seenCount = o.optInt("seenCount", 1)
                )
            )
        }
        return list
    }

    private fun saveAll(records: List<IconRecord>) {
        val arr = JSONArray()
        for (r in records) {
            arr.put(JSONObject().apply {
                put("iconId", r.iconId)
                put("hash", r.hash)
                put("imagePath", r.imagePath)
                put("confirmedName", r.confirmedName ?: "")
                put("predictedName", r.predictedName ?: "")
                put("seenCount", r.seenCount)
            })
        }
        dbFile.writeText(arr.toString(2))
    }
}
