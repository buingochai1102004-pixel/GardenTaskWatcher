package com.phuc.gardentaskwatcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import java.io.File

class TaskScanner(private val context: Context) {
    private val ocr = OcrEngine()

    fun scanPage(screenshot: Bitmap, pageIndex: Int): PageScanResult {
        val scaleX = screenshot.width.toFloat() / BotConfig.BASE_WIDTH
        val scaleY = screenshot.height.toFloat() / BotConfig.BASE_HEIGHT

        val results = BotConfig.slots.map { cfg ->
            val rect = Rect(
                (cfg.x1 * scaleX).toInt(),
                (cfg.y1 * scaleY).toInt(),
                (cfg.x2 * scaleX).toInt(),
                (cfg.y2 * scaleY).toInt()
            )

            val left = rect.left.coerceAtLeast(0)
            val top = rect.top.coerceAtLeast(0)
            val width = rect.width().coerceAtMost(screenshot.width - left)
            val height = rect.height().coerceAtMost(screenshot.height - top)

            val slotBitmap = Bitmap.createBitmap(screenshot, left, top, width, height)

            val text = ocr.readTextBlocking(slotBitmap)
            val status = StatusClassifier.classify(slotBitmap, text)
            val icon = if (status == TaskStatus.AVAILABLE) cropIcon(slotBitmap) else null
            val debugHash = ImageHash.dHash(slotBitmap)

            saveDebugSlot(pageIndex, cfg.slot, status, slotBitmap)

            SlotScanResult(
                slot = cfg.slot,
                status = status,
                ocrText = text,
                iconBitmap = icon,
                debugHash = debugHash
            )
        }

        val signature = results.joinToString("|") { "${it.slot}:${it.status}:${it.debugHash}" }
        return PageScanResult(pageIndex, results, ImageHash.stringHash(signature))
    }

    private fun cropIcon(slotBitmap: Bitmap): Bitmap {
        val x1 = (slotBitmap.width * BotConfig.ICON_X1_P).toInt()
        val y1 = (slotBitmap.height * BotConfig.ICON_Y1_P).toInt()
        val x2 = (slotBitmap.width * BotConfig.ICON_X2_P).toInt()
        val y2 = (slotBitmap.height * BotConfig.ICON_Y2_P).toInt()
        return Bitmap.createBitmap(slotBitmap, x1, y1, x2 - x1, y2 - y1)
    }

    private fun saveDebugSlot(pageIndex: Int, slot: Int, status: TaskStatus, bitmap: Bitmap) {
        try {
            val dir = File(context.filesDir, "debug_slots/page_$pageIndex")
            dir.mkdirs()
            val file = File(dir, "slot_${slot}_${status}.png")
            file.outputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
        } catch (_: Exception) {}
    }
}
