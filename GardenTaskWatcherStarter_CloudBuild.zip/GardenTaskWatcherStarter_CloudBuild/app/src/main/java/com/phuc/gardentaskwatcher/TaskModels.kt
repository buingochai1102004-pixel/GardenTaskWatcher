package com.phuc.gardentaskwatcher

import android.graphics.Bitmap

enum class TaskStatus {
    WAITING,
    DOING,
    VIP,
    AVAILABLE,
    UNKNOWN
}

data class SlotScanResult(
    val slot: Int,
    val status: TaskStatus,
    val ocrText: String,
    val iconBitmap: Bitmap?,
    val costLeft: Int? = null,
    val costRight: Int? = null,
    val debugHash: String
)

data class PageScanResult(
    val pageIndex: Int,
    val slots: List<SlotScanResult>,
    val signature: String
) {
    fun summary(): String {
        return "Page $pageIndex: " + slots.joinToString(" | ") {
            "S${it.slot}:${it.status}${if (it.ocrText.isNotBlank()) "(${it.ocrText.take(20)})" else ""}"
        }
    }
}

data class IconRecord(
    val iconId: String,
    val hash: String,
    val imagePath: String,
    val confirmedName: String? = null,
    val predictedName: String? = null,
    val seenCount: Int = 1
)
