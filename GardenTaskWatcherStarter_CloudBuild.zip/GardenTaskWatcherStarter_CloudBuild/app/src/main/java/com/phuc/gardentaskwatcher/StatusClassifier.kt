package com.phuc.gardentaskwatcher

import android.graphics.Bitmap

object StatusClassifier {
    private val timeRegex = Regex("""\b\d{1,2}:\d{2}:\d{2}\b|\b\d{1,2}:\d{2}\b""")

    fun classify(slotBitmap: Bitmap, ocrText: String): TaskStatus {
        val normalized = ocrText.lowercase()

        if (normalized.contains("đang") || normalized.contains("dang") || normalized.contains("tiến hành") || normalized.contains("tien hanh")) {
            return TaskStatus.DOING
        }

        if (timeRegex.containsMatchIn(normalized)) {
            return TaskStatus.WAITING
        }

        if (normalized.contains("vip")) {
            return TaskStatus.VIP
        }

        // Fallback v1: nếu card có đủ chi tiết màu/sáng thì coi là có icon.
        // Rule này sẽ được chỉnh tiếp bằng ảnh thật sau vài lần chạy debug.
        if (looksLikeAvailableIcon(slotBitmap)) {
            return TaskStatus.AVAILABLE
        }

        return TaskStatus.UNKNOWN
    }

    private fun looksLikeAvailableIcon(bitmap: Bitmap): Boolean {
        val x1 = (bitmap.width * 0.18f).toInt()
        val y1 = (bitmap.height * 0.08f).toInt()
        val x2 = (bitmap.width * 0.82f).toInt()
        val y2 = (bitmap.height * 0.62f).toInt()

        var colorfulPixels = 0
        var sampled = 0

        var y = y1
        while (y < y2) {
            var x = x1
            while (x < x2) {
                val c = bitmap.getPixel(x, y)
                val r = (c shr 16) and 0xff
                val g = (c shr 8) and 0xff
                val b = c and 0xff
                val max = maxOf(r, g, b)
                val min = minOf(r, g, b)
                if (max - min > 35 && max > 80) colorfulPixels++
                sampled++
                x += 4
            }
            y += 4
        }

        val ratio = if (sampled == 0) 0f else colorfulPixels.toFloat() / sampled
        return ratio > 0.18f
    }
}
