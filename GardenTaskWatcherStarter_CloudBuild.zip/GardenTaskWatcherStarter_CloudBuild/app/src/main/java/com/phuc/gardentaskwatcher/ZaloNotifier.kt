package com.phuc.gardentaskwatcher

import android.content.Context
import java.io.File

class ZaloNotifier(private val context: Context) {
    private val outboxFile = File(context.filesDir, "pending_zalo_messages.log")

    fun sendOrQueue(message: String) {
        // V1 chưa gửi Zalo thật. Ta ghi log trước để test nhận diện không spam.
        outboxFile.appendText("\n--- ${System.currentTimeMillis()} ---\n$message\n")
        LogStore.append(context, "Queued Zalo message:\n$message")

        // V2:
        // - Nếu có Zalo OA/GMF token: gọi API gửi nhóm.
        // - Nếu không có API: chuyển sang module AutoSender dùng Accessibility để mở Zalo, dán tin, gửi.
    }
}
