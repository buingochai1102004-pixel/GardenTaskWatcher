package com.phuc.gardentaskwatcher

object TaskKeyBuilder {
    fun build(iconId: String, slot: SlotScanResult): String {
        // V1: chưa OCR số nguyên liệu, nên dùng icon + status.
        // V2 sẽ thêm costLeft/costRight để phân biệt nhiệm vụ cùng icon.
        return listOf(
            iconId,
            slot.status.name,
            slot.costLeft ?: "x",
            slot.costRight ?: "x"
        ).joinToString("_")
    }
}
