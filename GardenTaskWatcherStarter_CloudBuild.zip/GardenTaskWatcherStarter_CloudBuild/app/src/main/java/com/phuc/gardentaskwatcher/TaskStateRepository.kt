package com.phuc.gardentaskwatcher

import android.content.Context
import org.json.JSONObject
import java.io.File

class TaskStateRepository(private val context: Context) {
    private val file = File(context.filesDir, "reported_tasks.json")

    @Synchronized
    fun shouldReport(taskKey: String): Boolean {
        val obj = load()
        return !obj.has(taskKey)
    }

    @Synchronized
    fun markReported(taskKey: String) {
        val obj = load()
        obj.put(taskKey, System.currentTimeMillis())
        file.writeText(obj.toString(2))
        LogStore.append(context, "Marked reported: $taskKey")
    }

    private fun load(): JSONObject {
        if (!file.exists()) return JSONObject()
        return try {
            JSONObject(file.readText())
        } catch (_: Exception) {
            JSONObject()
        }
    }
}
