package com.phuc.gardentaskwatcher

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val captureRequestCode = 7001
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermissionIfNeeded()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(36, 60, 36, 36)
        }

        statusText = TextView(this).apply {
            text = "Garden Task Watcher\nBước 1: bật Trợ năng.\nBước 2: xin quyền chụp màn hình.\nBước 3: mở game ở màn nhiệm vụ rồi bấm Bắt đầu."
            textSize = 17f
            setPadding(0, 0, 0, 32)
        }

        val btnAccessibility = Button(this).apply {
            text = "1. Mở cài đặt Trợ năng"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val btnCapture = Button(this).apply {
            text = "2. Xin quyền chụp màn hình"
            setOnClickListener {
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), captureRequestCode)
            }
        }

        val btnStop = Button(this).apply {
            text = "Dừng bot"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                statusText.text = "Đã gửi lệnh dừng bot."
            }
        }

        val btnOpenSettings = Button(this).apply {
            text = "Mở thông tin app / bỏ tiết kiệm pin"
            setOnClickListener {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            }
        }

        layout.addView(statusText)
        layout.addView(btnAccessibility)
        layout.addView(btnCapture)
        layout.addView(btnStop)
        layout.addView(btnOpenSettings)
        setContentView(layout)
    }

    @Deprecated("Dùng tạm cho starter project để dễ hiểu.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequestCode && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }

            statusText.text = "Bot đã bắt đầu. Giữ game ở màn nhiệm vụ. Log sẽ được lưu trong bộ nhớ app."
        } else {
            statusText.text = "Chưa được cấp quyền chụp màn hình."
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9001)
        }
    }
}
