package com.phuc.gardentaskwatcher

import android.graphics.Bitmap
import java.security.MessageDigest
import kotlin.math.min

object ImageHash {
    fun dHash(bitmap: Bitmap, hashSize: Int = 8): String {
        val scaled = Bitmap.createScaledBitmap(bitmap, hashSize + 1, hashSize, true)
        var value = 0UL

        for (y in 0 until hashSize) {
            for (x in 0 until hashSize) {
                val left = gray(scaled.getPixel(x, y))
                val right = gray(scaled.getPixel(x + 1, y))
                value = (value shl 1) or if (left > right) 1UL else 0UL
            }
        }
        scaled.recycle()
        return value.toString(16).padStart(16, '0')
    }

    fun hammingDistanceHex(a: String, b: String): Int {
        val len = min(a.length, b.length)
        var distance = 0
        for (i in 0 until len) {
            val x = a[i].digitToIntOrNull(16) ?: 0
            val y = b[i].digitToIntOrNull(16) ?: 0
            distance += Integer.bitCount(x xor y)
        }
        return distance + kotlin.math.abs(a.length - b.length) * 4
    }

    fun stringHash(input: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(input.toByteArray()).joinToString("") { "%02x".format(it) }.take(16)
    }

    private fun gray(color: Int): Int {
        val r = (color shr 16) and 0xff
        val g = (color shr 8) and 0xff
        val b = color and 0xff
        return (r * 30 + g * 59 + b * 11) / 100
    }
}
