package com.phuc.gardentaskwatcher

object MessageFormatter {
    fun formatNewTask(icon: IconRecord, pageIndex: Int, slot: SlotScanResult): String {
        val name = icon.confirmedName ?: icon.predictedName ?: "chưa đặt tên"
        return buildString {
            appendLine("🌸 Có nhiệm vụ mới!")
            appendLine()
            appendLine("Mã icon: ${icon.iconId}")
            appendLine("Tên: $name")
            appendLine("Vị trí: trang ${pageIndex + 1}, ô ${slot.slot}")
            appendLine("Trạng thái: Có thể nhận")
            appendLine()
            appendLine("Bot đã lưu icon vào danh sách.")
        }
    }
}
