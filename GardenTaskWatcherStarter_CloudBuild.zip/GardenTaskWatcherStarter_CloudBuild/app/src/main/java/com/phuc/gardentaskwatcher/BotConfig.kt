package com.phuc.gardentaskwatcher

data class RectConfig(
    val slot: Int,
    val x1: Int,
    val y1: Int,
    val x2: Int,
    val y2: Int
)

data class SwipeConfig(
    val x: Int = 345,
    val startY: Int = 1030,
    val endY: Int = 560,
    val durationMs: Long = 450,
    val delayAfterSwipeMs: Long = 1000
)

object BotConfig {
    // Tọa độ gốc lấy theo ảnh mẫu 686 x 1536.
    const val BASE_WIDTH = 686
    const val BASE_HEIGHT = 1536

    val slots = listOf(
        RectConfig(1, 82,  560, 235, 720),
        RectConfig(2, 267, 560, 420, 720),
        RectConfig(3, 452, 560, 605, 720),

        RectConfig(4, 82,  735, 235, 895),
        RectConfig(5, 267, 735, 420, 895),
        RectConfig(6, 452, 735, 605, 895),

        RectConfig(7, 82,  910, 235, 1070),
        RectConfig(8, 267, 910, 420, 1070),
        RectConfig(9, 452, 910, 605, 1070)
    )

    val swipe = SwipeConfig()

    const val SCAN_INTERVAL_MS = 15_000L
    const val MAX_PAGES_PER_CYCLE = 12
    const val SAME_PAGE_STOP_COUNT = 2

    // Cắt phần icon chính giữa card.
    const val ICON_X1_P = 0.18f
    const val ICON_Y1_P = 0.08f
    const val ICON_X2_P = 0.82f
    const val ICON_Y2_P = 0.62f
}
