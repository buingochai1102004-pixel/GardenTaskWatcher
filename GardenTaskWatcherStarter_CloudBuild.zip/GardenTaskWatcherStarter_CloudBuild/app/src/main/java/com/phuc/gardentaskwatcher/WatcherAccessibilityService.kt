package com.phuc.gardentaskwatcher

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class WatcherAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: WatcherAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        LogStore.append(applicationContext, "Accessibility service connected")
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Không cần đọc nội dung app. Bot chỉ dùng service này để vuốt.
    }

    override fun onInterrupt() {}

    fun swipeTaskList(config: SwipeConfig = BotConfig.swipe) {
        val path = Path().apply {
            moveTo(config.x.toFloat(), config.startY.toFloat())
            lineTo(config.x.toFloat(), config.endY.toFloat())
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, config.durationMs))
            .build()

        dispatchGesture(gesture, null, null)
        LogStore.append(applicationContext, "Swipe: x=${config.x}, ${config.startY}->${config.endY}")
    }
}
